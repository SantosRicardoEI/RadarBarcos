#ifndef MODULO_H
#define MODULO_H

// ================================================ MODULOS ============================================================

#include "stdlib.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "estruturas.h"
#include "input.h"
#include "simulacao.h"
#include "impressao.h"
#include "interface.h"
#include "memoria.h"

#endif
